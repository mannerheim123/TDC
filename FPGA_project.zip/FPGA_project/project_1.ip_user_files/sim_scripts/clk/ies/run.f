-makelib ies_lib/xil_defaultlib -sv \
  "D:/vivado_18_3/Vivado/2018.3/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
-endlib
-makelib ies_lib/xpm \
  "D:/vivado_18_3/Vivado/2018.3/data/ip/xpm/xpm_VCOMP.vhd" \
-endlib
-makelib ies_lib/xil_defaultlib \
  "../../../../project_1.srcs/sources_1/ip/clk/clk_clk_wiz.v" \
  "../../../../project_1.srcs/sources_1/ip/clk/clk.v" \
-endlib
-makelib ies_lib/xil_defaultlib \
  glbl.v
-endlib

