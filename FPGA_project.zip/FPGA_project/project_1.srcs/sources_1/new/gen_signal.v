module gen_signal(
    input  wire       sys_clk,   // ����� clk_400m
    input  wire       rst_n,

    output reg        start,
    output reg [3:0]  signal
);

    // clk_400m = 2.5ns
    // signal[0]��start �� 100ns ���� -> 40 ������
    // signal[1]��start �� 120ns ���� -> 48 ������
    // signal[2]��start �� 140ns ���� -> 56 ������
    // signal[3]��start �� 160ns ���� -> 64 ������
    //
    // ���ڷ�������ֵ�������� 39/47/55/63 ����
    localparam [6:0] T0_START = 7'd39;
    localparam [6:0] T1_START = 7'd47;
    localparam [6:0] T2_START = 7'd55;
    localparam [6:0] T3_START = 7'd63;

    // 12.5MHz ���� = 80ns = 32 �� 400MHz ����
    // �ߵ�ƽ 40ns = 16 �� 400MHz ����
    localparam [4:0] HIGH_END = 5'd16;

    reg [6:0] wait_cnt;

    reg       en0, en1, en2, en3;
    reg [4:0] ph0, ph1, ph2, ph3;

    always @(posedge sys_clk or negedge rst_n) begin
        if(!rst_n) begin
            start    <= 1'b0;
            signal   <= 4'b0000;

            wait_cnt <= 7'd0;

            en0 <= 1'b0;
            en1 <= 1'b0;
            en2 <= 1'b0;
            en3 <= 1'b0;

            ph0 <= 5'd0;
            ph1 <= 5'd0;
            ph2 <= 5'd0;
            ph3 <= 5'd0;
        end
        else begin
            // ��λ�ͷź��Զ�����
            start <= 1'b1;

            // �ȴ��������� 64 �����ں�ֹͣ
            if(wait_cnt < 7'd64)
                wait_cnt <= wait_cnt + 1'b1;

            // =========================
            // signal[0]
            // =========================
            if(en0) begin
                signal[0] <= (ph0 < HIGH_END);
                ph0       <= ph0 + 1'b1;
            end
            else if(wait_cnt == T0_START) begin
                en0       <= 1'b1;
                signal[0] <= 1'b1;
                ph0       <= 5'd1;
            end
            else begin
                signal[0] <= 1'b0;
            end

            // =========================
            // signal[1]
            // =========================
            if(en1) begin
                signal[1] <= (ph1 < HIGH_END);
                ph1       <= ph1 + 1'b1;
            end
            else if(wait_cnt == T1_START) begin
                en1       <= 1'b1;
                signal[1] <= 1'b1;
                ph1       <= 5'd1;
            end
            else begin
                signal[1] <= 1'b0;
            end

            // =========================
            // signal[2]
            // =========================
            if(en2) begin
                signal[2] <= (ph2 < HIGH_END);
                ph2       <= ph2 + 1'b1;
            end
            else if(wait_cnt == T2_START) begin
                en2       <= 1'b1;
                signal[2] <= 1'b1;
                ph2       <= 5'd1;
            end
            else begin
                signal[2] <= 1'b0;
            end

            // =========================
            // signal[3]
            // =========================
            if(en3) begin
                signal[3] <= (ph3 < HIGH_END);
                ph3       <= ph3 + 1'b1;
            end
            else if(wait_cnt == T3_START) begin
                en3       <= 1'b1;
                signal[3] <= 1'b1;
                ph3       <= 5'd1;
            end
            else begin
                signal[3] <= 1'b0;
            end
        end
    end

endmodule