`timescale 1ns / 1ps

// ============================================================================
// ģ�鹦�ܣ�
// 200MHz ʱ���£�ÿ�� 3 ��ͨ�� UART ���� 4 �� 32 λ���ݵ� PC ��
//
// ���͸�ʽ��
// D0=0x12345678 D1=0x12345678 D2=0x12345678 D3=0x12345678\r\n
//
// ���ڲ�����
// 9600 bps, 8 data bits, 1 stop bit, no parity
// ============================================================================

module rs232
#(
    parameter integer UART_BPS          = 9600,
    parameter integer CLK_FREQ          = 200_000_000,
    parameter integer SEND_INTERVAL_SEC = 3
)
(
    input  wire        sys_clk,       // 200MHz ʱ��
    input  wire        sys_rst_n,     // ����Ч��λ

    input  wire [31:0] data0,
    input  wire [31:0] data1,
    input  wire [31:0] data2,
    input  wire [31:0] data3,

    output wire        tx
);

// ============================================================================
// ��������
// ============================================================================

localparam integer SEND_CNT_MAX = CLK_FREQ * SEND_INTERVAL_SEC;

// һ֡ ASCII �ַ������ȣ�
// D0=0xXXXXXXXX �ո� D1=0xXXXXXXXX �ո� D2=0xXXXXXXXX �ո� D3=0xXXXXXXXX \r \n
// 14 + 14 + 14 + 13 + 2 = 57
localparam integer PACKET_LEN = 57;

// ״̬��״̬
localparam [1:0] ST_IDLE      = 2'd0;
localparam [1:0] ST_SEND_BYTE = 2'd1;
localparam [1:0] ST_WAIT_BUSY = 2'd2;
localparam [1:0] ST_WAIT_DONE = 2'd3;

// ============================================================================
// 3 �붨ʱ������
// ============================================================================

reg [31:0] send_cnt;
reg        send_tick;

always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        send_cnt  <= 32'd0;
        send_tick <= 1'b0;
    end
    else begin
        if(send_cnt >= SEND_CNT_MAX - 1) begin
            send_cnt  <= 32'd0;
            send_tick <= 1'b1;
        end
        else begin
            send_cnt  <= send_cnt + 1'b1;
            send_tick <= 1'b0;
        end
    end
end

// ============================================================================
// ���� 4 �� 32 λ��������
// ���� 3 �뷢��ʱ�̺��Ȱ� data0~data3 ��������
// �������Ա��ⷢ�͹������������ݱ仯����һ֡����ǰ��һ��
// ============================================================================

reg [31:0] data0_r;
reg [31:0] data1_r;
reg [31:0] data2_r;
reg [31:0] data3_r;

// ============================================================================
// UART ���Ϳ����ź�
// ============================================================================

reg  [7:0] tx_data;
reg        tx_start;
wire       tx_busy;

reg [1:0] state;
reg [5:0] byte_cnt;

// ============================================================================
// 4bit ʮ��������ת ASCII
// 0~9  -> "0"~"9"
// A~F  -> "A"~"F"
// ============================================================================

function [7:0] hex_to_ascii;
    input [3:0] hex;
    begin
        if(hex <= 4'd9)
            hex_to_ascii = 8'h30 + hex;          // 0~9
        else
            hex_to_ascii = 8'h41 + hex - 4'd10;  // A~F
    end
endfunction

// ============================================================================
// �� 32 λ������ȡ��ĳһ�� 4bit
// pos = 0 ȡ [31:28]
// pos = 1 ȡ [27:24]
// ...
// pos = 7 ȡ [3:0]
// ============================================================================

function [3:0] get_nibble;
    input [31:0] data;
    input [2:0]  pos;
    begin
        case(pos)
            3'd0: get_nibble = data[31:28];
            3'd1: get_nibble = data[27:24];
            3'd2: get_nibble = data[23:20];
            3'd3: get_nibble = data[19:16];
            3'd4: get_nibble = data[15:12];
            3'd5: get_nibble = data[11:8];
            3'd6: get_nibble = data[7:4];
            3'd7: get_nibble = data[3:0];
            default: get_nibble = 4'd0;
        endcase
    end
endfunction

// ============================================================================
// ���� byte_cnt ���ɵ�ǰҪ���͵� ASCII �ֽ�
// ============================================================================

function [7:0] packet_byte;
    input [5:0] index;
    begin
        // D0 �� 8 ��ʮ�������ַ���index = 5~12
        if(index >= 6'd5 && index <= 6'd12) begin
            packet_byte = hex_to_ascii(get_nibble(data0_r, index - 6'd5));
        end

        // D1 �� 8 ��ʮ�������ַ���index = 19~26
        else if(index >= 6'd19 && index <= 6'd26) begin
            packet_byte = hex_to_ascii(get_nibble(data1_r, index - 6'd19));
        end

        // D2 �� 8 ��ʮ�������ַ���index = 33~40
        else if(index >= 6'd33 && index <= 6'd40) begin
            packet_byte = hex_to_ascii(get_nibble(data2_r, index - 6'd33));
        end

        // D3 �� 8 ��ʮ�������ַ���index = 47~54
        else if(index >= 6'd47 && index <= 6'd54) begin
            packet_byte = hex_to_ascii(get_nibble(data3_r, index - 6'd47));
        end

        else begin
            case(index)
                // D0=0x
                6'd0 : packet_byte = 8'h44; // D
                6'd1 : packet_byte = 8'h30; // 0
                6'd2 : packet_byte = 8'h3D; // =
                6'd3 : packet_byte = 8'h30; // 0
                6'd4 : packet_byte = 8'h78; // x
                6'd13: packet_byte = 8'h20; // space

                // D1=0x
                6'd14: packet_byte = 8'h44; // D
                6'd15: packet_byte = 8'h31; // 1
                6'd16: packet_byte = 8'h3D; // =
                6'd17: packet_byte = 8'h30; // 0
                6'd18: packet_byte = 8'h78; // x
                6'd27: packet_byte = 8'h20; // space

                // D2=0x
                6'd28: packet_byte = 8'h44; // D
                6'd29: packet_byte = 8'h32; // 2
                6'd30: packet_byte = 8'h3D; // =
                6'd31: packet_byte = 8'h30; // 0
                6'd32: packet_byte = 8'h78; // x
                6'd41: packet_byte = 8'h20; // space

                // D3=0x
                6'd42: packet_byte = 8'h44; // D
                6'd43: packet_byte = 8'h33; // 3
                6'd44: packet_byte = 8'h3D; // =
                6'd45: packet_byte = 8'h30; // 0
                6'd46: packet_byte = 8'h78; // x

                // ����
                6'd55: packet_byte = 8'h0D; // \r
                6'd56: packet_byte = 8'h0A; // \n

                default: packet_byte = 8'h20;
            endcase
        end
    end
endfunction

// ============================================================================
// ������״̬��
// ============================================================================

always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        data0_r  <= 32'd0;
        data1_r  <= 32'd0;
        data2_r  <= 32'd0;
        data3_r  <= 32'd0;

        tx_data  <= 8'd0;
        tx_start <= 1'b0;

        byte_cnt <= 6'd0;
        state    <= ST_IDLE;
    end
    else begin
        tx_start <= 1'b0;

        case(state)

            // �ȴ� 3 �붨ʱ����
            ST_IDLE: begin
                if(send_tick == 1'b1) begin
                    data0_r  <= data0;
                    data1_r  <= data1;
                    data2_r  <= data2;
                    data3_r  <= data3;

                    byte_cnt <= 6'd0;
                    state    <= ST_SEND_BYTE;
                end
            end

            // �������͵�ǰ�ֽ�
            ST_SEND_BYTE: begin
                if(tx_busy == 1'b0) begin
                    tx_data  <= packet_byte(byte_cnt);
                    tx_start <= 1'b1;
                    state    <= ST_WAIT_BUSY;
                end
            end

            // �ȴ� uart_tx_byte ����æ״̬
            ST_WAIT_BUSY: begin
                if(tx_busy == 1'b1) begin
                    state <= ST_WAIT_DONE;
                end
            end

            // �ȴ���ǰ�ֽڷ������
            ST_WAIT_DONE: begin
                if(tx_busy == 1'b0) begin
                    if(byte_cnt == PACKET_LEN - 1) begin
                        byte_cnt <= 6'd0;
                        state    <= ST_IDLE;
                    end
                    else begin
                        byte_cnt <= byte_cnt + 1'b1;
                        state    <= ST_SEND_BYTE;
                    end
                end
            end

            default: begin
                state <= ST_IDLE;
            end

        endcase
    end
end

// ============================================================================
// ���ֽ� UART ����ģ��
// ============================================================================

uart_tx_byte #(
    .UART_BPS(UART_BPS),
    .CLK_FREQ(CLK_FREQ)
)
uart_tx_byte_inst (
    .sys_clk   (sys_clk),
    .sys_rst_n (sys_rst_n),
    .tx_data   (tx_data),
    .tx_start  (tx_start),
    .tx        (tx),
    .tx_busy   (tx_busy)
);

endmodule


// ============================================================================
// ���ֽ� UART ����ģ��
// ���ܣ�����һ�� 8 λ���ݣ�tx_start ���� 1 ��ʱ�����ں�ʼ����
// ��ʽ��1 ��ʼλ + 8 ����λ + 1 ֹͣλ
// ============================================================================

module uart_tx_byte
#(
    parameter integer UART_BPS = 9600,
    parameter integer CLK_FREQ = 200_000_000
)
(
    input  wire       sys_clk,
    input  wire       sys_rst_n,

    input  wire [7:0] tx_data,
    input  wire       tx_start,

    output reg        tx,
    output wire       tx_busy
);

localparam integer BAUD_CNT_MAX = CLK_FREQ / UART_BPS;

localparam [1:0] ST_IDLE  = 2'd0;
localparam [1:0] ST_START = 2'd1;
localparam [1:0] ST_DATA  = 2'd2;
localparam [1:0] ST_STOP  = 2'd3;

reg [1:0]  state;
reg [31:0] baud_cnt;
reg [2:0]  bit_cnt;
reg [7:0]  data_reg;

assign tx_busy = (state != ST_IDLE);

always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        state    <= ST_IDLE;
        baud_cnt <= 32'd0;
        bit_cnt  <= 3'd0;
        data_reg <= 8'd0;
        tx       <= 1'b1;
    end
    else begin
        case(state)

            // ����״̬��tx ���ָߵ�ƽ
            ST_IDLE: begin
                tx       <= 1'b1;
                baud_cnt <= 32'd0;
                bit_cnt  <= 3'd0;

                if(tx_start == 1'b1) begin
                    data_reg <= tx_data;
                    tx       <= 1'b0;      // ��ʼλ
                    state    <= ST_START;
                end
            end

            // ������ʼλ 0
            ST_START: begin
                tx <= 1'b0;

                if(baud_cnt >= BAUD_CNT_MAX - 1) begin
                    baud_cnt <= 32'd0;
                    bit_cnt  <= 3'd0;
                    tx       <= data_reg[0];
                    state    <= ST_DATA;
                end
                else begin
                    baud_cnt <= baud_cnt + 1'b1;
                end
            end

            // ���� 8 λ���ݣ���λ�ȷ�
            ST_DATA: begin
                tx <= data_reg[bit_cnt];

                if(baud_cnt >= BAUD_CNT_MAX - 1) begin
                    baud_cnt <= 32'd0;

                    if(bit_cnt == 3'd7) begin
                        tx    <= 1'b1;     // ֹͣλ
                        state <= ST_STOP;
                    end
                    else begin
                        bit_cnt <= bit_cnt + 1'b1;
                        tx      <= data_reg[bit_cnt + 1'b1];
                    end
                end
                else begin
                    baud_cnt <= baud_cnt + 1'b1;
                end
            end

            // ����ֹͣλ 1
            ST_STOP: begin
                tx <= 1'b1;

                if(baud_cnt >= BAUD_CNT_MAX - 1) begin
                    baud_cnt <= 32'd0;
                    state    <= ST_IDLE;
                end
                else begin
                    baud_cnt <= baud_cnt + 1'b1;
                end
            end

            default: begin
                state <= ST_IDLE;
            end

        endcase
    end
end

endmodule
