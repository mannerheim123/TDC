`timescale 1ns / 1ps

module tdc_test_signal_gen_200m
#(
    parameter integer MODE = 1       // 0: ��·ͬ����1: ��·���20ns
)
(
    input  wire       clk_200m,
    input  wire       rst_n,

    output reg        start,
    output reg [3:0]  sig_out
);

//==================================================
// 200MHz ʱ�ӣ�һ������ 5ns
// 100ns = 20 ������
// 200ns = 40 ������
// 12.5MHz ���� = 80ns = 16 ������
// 20ns ��λ�� = 4 ������
//==================================================
localparam integer START_LOW_CYC  = 20;
localparam integer START_HOLD_CYC = 40;

localparam [1:0] ST_WAIT_LOW = 2'd0;
localparam [1:0] ST_START    = 2'd1;
localparam [1:0] ST_RUN      = 2'd2;

reg [1:0] state;
reg [7:0] delay_cnt;
reg [3:0] wave_cnt;

always @(posedge clk_200m or negedge rst_n) begin
    if(!rst_n) begin
        state     <= ST_WAIT_LOW;
        delay_cnt <= 8'd0;
        wave_cnt  <= 4'd0;
        start     <= 1'b0;
        sig_out   <= 4'b0000;
    end
    else begin
        case(state)

            //==================================================
            // ����ǰ���ȱ��� start = 0��signal = 0������100ns
            //==================================================
            ST_WAIT_LOW: begin
                start    <= 1'b0;
                sig_out  <= 4'b0000;
                wave_cnt <= 4'd0;

                if(delay_cnt == START_LOW_CYC - 1) begin
                    delay_cnt <= 8'd0;
                    state     <= ST_START;
                end
                else begin
                    delay_cnt <= delay_cnt + 1'b1;
                end
            end

            //==================================================
            // start ���ߣ��� signal �Ա��ֵ͵�ƽ������200ns
            //==================================================
            ST_START: begin
                start    <= 1'b1;
                sig_out  <= 4'b0000;
                wave_cnt <= 4'd0;

                if(delay_cnt == START_HOLD_CYC - 1) begin
                    delay_cnt <= 8'd0;
                    state     <= ST_RUN;
                end
                else begin
                    delay_cnt <= delay_cnt + 1'b1;
                end
            end

            //==================================================
            // �������У�
            // start һֱ���ָߵ�ƽ
            // sig_out ��� 12.5MHz ��·�ź�
            //==================================================
            ST_RUN: begin
                start     <= 1'b1;
                delay_cnt <= 8'd0;

                if(wave_cnt == 4'd15)
                    wave_cnt <= 4'd0;
                else
                    wave_cnt <= wave_cnt + 1'b1;

                if(MODE == 0) begin
                    // ��·ͬ�� 12.5MHz��50%ռ�ձ�
                    if(wave_cnt < 4'd8)
                        sig_out <= 4'b1111;
                    else
                        sig_out <= 4'b0000;
                end
                else begin
                    // ��·���20ns
                    // 200MHz �� 20ns = 4 ��ʱ������
                    case(wave_cnt[3:2])
                        2'd0: sig_out <= 4'b1001;
                        2'd1: sig_out <= 4'b0011;
                        2'd2: sig_out <= 4'b0110;
                        2'd3: sig_out <= 4'b1100;
                        default: sig_out <= 4'b0000;
                    endcase
                end
            end

            default: begin
                state     <= ST_WAIT_LOW;
                delay_cnt <= 8'd0;
                wave_cnt  <= 4'd0;
                start     <= 1'b0;
                sig_out   <= 4'b0000;
            end

        endcase
    end
end

endmodule