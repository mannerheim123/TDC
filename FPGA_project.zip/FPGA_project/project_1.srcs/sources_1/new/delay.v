`timescale 1ns / 1ps

module delay #(
    parameter integer COARSE_PERIOD_PS  = 2500,
    parameter integer IODELAY_TAP_PS    = 78,
    parameter integer IODELAY_MAX_TAP   = 31,
    parameter integer DIRECT_LIMIT_PS   = 2500,
    parameter integer COARSE_DEPTH      = 30
)(
    input  wire        clk_400m,
    input  wire        rst_n,

    input  wire [3:0]  sig_in,

    input  wire [4:0]  delay_count0,
    input  wire [4:0]  delay_count1,
    input  wire [4:0]  delay_count2,
    input  wire [4:0]  delay_count3,
    input  wire        direct_mode,
    input  wire        valid,

    output wire [3:0]  sig_sync,
    output reg         align_valid
);

    reg [4:0] tap0;
    reg [4:0] tap1;
    reg [4:0] tap2;
    reg [4:0] tap3;

    reg [4:0] coarse_cnt0;
    reg [4:0] coarse_cnt1;
    reg [4:0] coarse_cnt2;
    reg [4:0] coarse_cnt3;

    reg       mode_r;
    reg       load_finish;
    reg       load_idelay_r;
    reg [2:0] state;

    // ============================================================
    // Load delay configuration
    //
    // mode_r = 1: small-range mode, use IDELAYE2
    // mode_r = 0: large-range mode, use coarse FIFO delay
    // ============================================================
    always @(posedge clk_400m or negedge rst_n) begin
        if (!rst_n) begin
            tap0          <= 5'd0;
            tap1          <= 5'd0;
            tap2          <= 5'd0;
            tap3          <= 5'd0;

            coarse_cnt0   <= 5'd0;
            coarse_cnt1   <= 5'd0;
            coarse_cnt2   <= 5'd0;
            coarse_cnt3   <= 5'd0;

            mode_r        <= 1'b0;
            load_finish   <= 1'b0;
            load_idelay_r <= 1'b0;
            state         <= 3'd0;
        end
        else begin
            load_idelay_r <= 1'b0;

            case (state)

                3'd0: begin
                    load_finish <= 1'b0;

                    if (valid) begin
                        mode_r <= direct_mode;

                        if (direct_mode) begin
                            tap0 <= delay_count0;
                            tap1 <= delay_count1;
                            tap2 <= delay_count2;
                            tap3 <= delay_count3;
                        end
                        else begin
                            coarse_cnt0 <= delay_count0;
                            coarse_cnt1 <= delay_count1;
                            coarse_cnt2 <= delay_count2;
                            coarse_cnt3 <= delay_count3;
                        end

                        state <= 3'd1;
                    end
                end

                3'd1: begin
                    if (mode_r) begin
                        load_idelay_r <= 1'b1;
                    end

                    state <= 3'd2;
                end

                3'd2: begin
                    load_idelay_r <= 1'b0;
                    load_finish   <= 1'b1;
                    state         <= 3'd2;
                end

                default: begin
                    state <= 3'd0;
                end

            endcase
        end
    end

    // ============================================================
    // Coarse delay FIFO
    //
    // Only used in large-range mode.
    // ============================================================
    reg [COARSE_DEPTH:0] fifo [0:3];

    always @(posedge clk_400m or negedge rst_n) begin
        if (!rst_n) begin
            fifo[0] <= {COARSE_DEPTH+1{1'b0}};
            fifo[1] <= {COARSE_DEPTH+1{1'b0}};
            fifo[2] <= {COARSE_DEPTH+1{1'b0}};
            fifo[3] <= {COARSE_DEPTH+1{1'b0}};
        end
        else if (load_finish && !mode_r) begin
            fifo[0] <= {fifo[0][COARSE_DEPTH-1:0], sig_in[0]};
            fifo[1] <= {fifo[1][COARSE_DEPTH-1:0], sig_in[1]};
            fifo[2] <= {fifo[2][COARSE_DEPTH-1:0], sig_in[2]};
            fifo[3] <= {fifo[3][COARSE_DEPTH-1:0], sig_in[3]};
        end
    end

    // ============================================================
    // IDELAYE2 outputs
    // ============================================================
    wire [3:0] sig_idelay;

    IDELAYE2 #(
        .CINVCTRL_SEL("FALSE"),
        .DELAY_SRC("DATAIN"),
        .HIGH_PERFORMANCE_MODE("TRUE"),
        .IDELAY_TYPE("VAR_LOAD"),
        .IDELAY_VALUE(0),
        .PIPE_SEL("FALSE"),
        .REFCLK_FREQUENCY(200.0),
        .SIGNAL_PATTERN("DATA")
    ) u_idelay0 (
        .DATAOUT(sig_idelay[0]),
        .C(clk_400m),
        .CE(1'b0),
        .CINVCTRL(1'b0),
        .CNTVALUEIN(tap0),
        .CNTVALUEOUT(),
        .DATAIN(sig_in[0]),
        .IDATAIN(1'b0),
        .INC(1'b0),
        .LD(load_idelay_r),
        .LDPIPEEN(1'b0),
        .REGRST(~rst_n)
    );

    IDELAYE2 #(
        .CINVCTRL_SEL("FALSE"),
        .DELAY_SRC("DATAIN"),
        .HIGH_PERFORMANCE_MODE("TRUE"),
        .IDELAY_TYPE("VAR_LOAD"),
        .IDELAY_VALUE(0),
        .PIPE_SEL("FALSE"),
        .REFCLK_FREQUENCY(200.0),
        .SIGNAL_PATTERN("DATA")
    ) u_idelay1 (
        .DATAOUT(sig_idelay[1]),
        .C(clk_400m),
        .CE(1'b0),
        .CINVCTRL(1'b0),
        .CNTVALUEIN(tap1),
        .CNTVALUEOUT(),
        .DATAIN(sig_in[1]),
        .IDATAIN(1'b0),
        .INC(1'b0),
        .LD(load_idelay_r),
        .LDPIPEEN(1'b0),
        .REGRST(~rst_n)
    );

    IDELAYE2 #(
        .CINVCTRL_SEL("FALSE"),
        .DELAY_SRC("DATAIN"),
        .HIGH_PERFORMANCE_MODE("TRUE"),
        .IDELAY_TYPE("VAR_LOAD"),
        .IDELAY_VALUE(0),
        .PIPE_SEL("FALSE"),
        .REFCLK_FREQUENCY(200.0),
        .SIGNAL_PATTERN("DATA")
    ) u_idelay2 (
        .DATAOUT(sig_idelay[2]),
        .C(clk_400m),
        .CE(1'b0),
        .CINVCTRL(1'b0),
        .CNTVALUEIN(tap2),
        .CNTVALUEOUT(),
        .DATAIN(sig_in[2]),
        .IDATAIN(1'b0),
        .INC(1'b0),
        .LD(load_idelay_r),
        .LDPIPEEN(1'b0),
        .REGRST(~rst_n)
    );

    IDELAYE2 #(
        .CINVCTRL_SEL("FALSE"),
        .DELAY_SRC("DATAIN"),
        .HIGH_PERFORMANCE_MODE("TRUE"),
        .IDELAY_TYPE("VAR_LOAD"),
        .IDELAY_VALUE(0),
        .PIPE_SEL("FALSE"),
        .REFCLK_FREQUENCY(200.0),
        .SIGNAL_PATTERN("DATA")
    ) u_idelay3 (
        .DATAOUT(sig_idelay[3]),
        .C(clk_400m),
        .CE(1'b0),
        .CINVCTRL(1'b0),
        .CNTVALUEIN(tap3),
        .CNTVALUEOUT(),
        .DATAIN(sig_in[3]),
        .IDATAIN(1'b0),
        .INC(1'b0),
        .LD(load_idelay_r),
        .LDPIPEEN(1'b0),
        .REGRST(~rst_n)
    );

    // ============================================================
    // Large-range coarse output
    // ============================================================
    reg [3:0] coarse_sync_r;

    always @(posedge clk_400m or negedge rst_n) begin
        if (!rst_n) begin
            coarse_sync_r <= 4'b0000;
            align_valid   <= 1'b0;
        end
        else begin
            if (load_finish) begin
                align_valid <= 1'b1;
            end
            else begin
                align_valid <= 1'b0;
            end

            if (load_finish && !mode_r) begin
                coarse_sync_r <= {
                    fifo[3][coarse_cnt3],
                    fifo[2][coarse_cnt2],
                    fifo[1][coarse_cnt1],
                    fifo[0][coarse_cnt0]
                };
            end
        end
    end


    assign sig_sync = (load_finish && mode_r)  ? sig_idelay     :
                      (load_finish && !mode_r) ? coarse_sync_r  :4'b0000;

endmodule