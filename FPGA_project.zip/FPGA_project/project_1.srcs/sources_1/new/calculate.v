// ============================================================================
// calculateģ��
// ----------------------------------------------------------------------------
// ���ܣ�
// 1. ����TDC�����coarse + tap��
// 2. ��ʱ��ת��ΪƤ�뼶 delay_ps
// 3. ����·skew�Ƚϣ�max-min��
// 4. �ж��Ƿ���� direct_mode�����ӳٲ�����
// 5. ���� delay_count�����ں��ӳٵ��ڻ�DLL/�ӳ������ƣ�
// 6. UART����������
// ============================================================================
module calculate
#(
    parameter integer COARSE_PERIOD_PS = 2500,
    parameter integer MAX_DELAY_COARSE = 30,
    parameter integer TAP0_PS = 17,
    parameter integer TAP1_PS = 18,
    parameter integer TAP2_PS = 18,
    parameter integer TAP3_PS = 17
)
(
    input   wire        clk_200m    ,
    input   wire        rst_n       ,

    input wire [15:0] coarse0,
    input wire [15:0] coarse1,
    input wire [15:0] coarse2,
    input wire [15:0] coarse3,
                   
    input wire [8:0]  tap0   , 
    input wire [8:0]  tap1   , 
    input wire [8:0]  tap2   , 
    input wire [8:0]  tap3   , 
    
    
    input   wire        valid_in    ,
    output  reg         direct_mode ,
    output  reg  [4:0]  delay_count0,
    output  reg  [4:0]  delay_count1,
    output  reg  [4:0]  delay_count2,
    output  reg  [4:0]  delay_count3,
    
    output  reg         valid_out   , 
    output  wire        uart_tx  

);
// ============================================================================
// 1. delay_ps���㻺�棨coarse + fine��
// ----------------------------------------------------------------------------
// delay_ps = coarse * Tclk - tap * Ttap
// ����coarse���֣�����tap�������������
// ============================================================================
reg [31:0] delay0_ps_r;
reg [31:0] delay1_ps_r;
reg [31:0] delay2_ps_r;
reg [31:0] delay3_ps_r;
reg [15:0] coarse0_r1  ;
reg [15:0] coarse1_r1  ;
reg [15:0] coarse2_r1  ;
reg [15:0] coarse3_r1  ;
reg [8:0]  tap0_r1     ;
reg [8:0]  tap1_r1     ;
reg [8:0]  tap2_r1     ;
reg [8:0]  tap3_r1     ;
reg [15:0] coarse0_r2  ;
reg [15:0] coarse1_r2  ;
reg [15:0] coarse2_r2  ;
reg [15:0] coarse3_r2  ;
reg [8:0]  tap0_r2     ;
reg [8:0]  tap1_r2     ;
reg [8:0]  tap2_r2     ;
reg [8:0]  tap3_r2     ;
// ============================================================================
// 2. ״̬��state�������ڲ���TDC���
// ----------------------------------------------------------------------------
// ע�⣺���ﲻ����ϼ��㣬����"��������"������timing violation
// ============================================================================
reg [4:0]  state       ;
reg        valid_in_reg;
reg        locked      ;
// ============================================================================
// 3. ���ݲ�����delay_ps��������
// ============================================================================
always @(posedge clk_200m or negedge rst_n) begin
    if (!rst_n) begin
        delay0_ps_r <= 32'd0;
        delay1_ps_r <= 32'd0;
        delay2_ps_r <= 32'd0;
        delay3_ps_r <= 32'd0;
        coarse0_r1  <= 16'd0;
        coarse1_r1  <= 16'd0;
        coarse2_r1  <= 16'd0;
        coarse3_r1  <= 16'd0;
        coarse0_r2  <= 16'd0;
        coarse1_r2  <= 16'd0;
        coarse2_r2  <= 16'd0;
        coarse3_r2  <= 16'd0;
        tap0_r1     <= 9'd0;
        tap1_r1     <= 9'd0;
        tap2_r1     <= 9'd0;
        tap3_r1     <= 9'd0;
        tap0_r2     <= 9'd0;
        tap1_r2     <= 9'd0;
        tap2_r2     <= 9'd0;
        tap3_r2     <= 9'd0;
        
        locked      <= 1'b0;
        state       <= 3'b0;
        valid_in_reg<=0;
    end
    else begin
        valid_in_reg <= valid_in;
        if (valid_in && locked == 0) 
        begin
            case(state)
            0: begin coarse0_r1 <= coarse0;state<=state+1; end
            1: begin coarse1_r1 <= coarse1;state<=state+1; end
            2: begin coarse2_r1 <= coarse2;state<=state+1; end
            3: begin coarse3_r1 <= coarse3;state<=state+1; end
            4: begin tap0_r1    <= tap0 ;state<=state+1; end 
            5: begin tap1_r1    <= tap1 ;state<=state+1; end 
            6: begin tap2_r1    <= tap2 ;state<=state+1; end 
            7: begin tap3_r1    <= tap3 ;state<=state+1; end 
            8: begin coarse0_r2 <=coarse0_r1   ;state<=state+1; end
            9: begin coarse1_r2 <=coarse1_r1   ;state<=state+1; end
            10: begin coarse2_r2 <=coarse2_r1   ;state<=state+1; end
            11: begin coarse3_r2 <=coarse3_r1   ;state<=state+1; end
            12: begin tap0_r2    <=tap0_r1      ;state<=state+1; end  
            13: begin tap1_r2    <=tap1_r1      ;state<=state+1; end  
            14: begin tap2_r2    <=tap2_r1      ;state<=state+1; end  
            15: begin tap3_r2    <=tap3_r1      ;state<=state+1; end  
            16: begin delay0_ps_r <= coarse0_r2*COARSE_PERIOD_PS;state<=state+1; end
            17: begin delay0_ps_r <= delay0_ps_r-tap0_r2*TAP0_PS;state<=state+1; end
            18: begin delay1_ps_r <= coarse1_r2*COARSE_PERIOD_PS;state<=state+1; end
            19: begin delay1_ps_r <= delay1_ps_r-tap1_r2*TAP1_PS;state<=state+1; end
            20:begin delay2_ps_r <= coarse2_r2*COARSE_PERIOD_PS;state<=state+1; end
            21:begin delay2_ps_r <= delay2_ps_r-tap2_r2*TAP2_PS;state<=state+1; end
            22:begin delay3_ps_r <= coarse3_r2*COARSE_PERIOD_PS;state<=state+1; end
            23:begin delay3_ps_r <= delay3_ps_r-tap3_r2*TAP3_PS;state<=state+1; end
            24:locked<=1'b1;
            endcase
        end
    end
end
    
reg [31:0] max_delay_ps;
reg [31:0] max_delay_reg;
reg [31:0] min_delay_ps;
reg [31:0] diff_ps[3:0];
reg [31:0] skew;
reg        skew_flag;
reg [3:0]  cnt_compare;    
reg        compare_finish;

always @(posedge clk_200m or negedge rst_n) begin
    if (!rst_n) begin
        max_delay_ps   <= 32'd0;
        min_delay_ps   <= 32'd0;
        max_delay_reg  <= 32'd0;
        skew           <= 32'd0;
        skew_flag      <= 1'b0 ;
        diff_ps[0]     <= 32'd0;
        diff_ps[1]     <= 32'd0;
        diff_ps[2]     <= 32'd0;
        diff_ps[3]     <= 32'd0;

        cnt_compare    <= 4'd0;
        compare_finish <= 1'b0;
    end
    else if (valid_in_reg == 1'b1 && locked==1'b1) begin
        case (cnt_compare)

            4'd0: begin
                if (delay0_ps_r >= delay1_ps_r) begin
                    max_delay_ps <= delay0_ps_r;
                    min_delay_ps <= delay1_ps_r;
                end
                else begin
                    max_delay_ps <= delay1_ps_r;
                    min_delay_ps <= delay0_ps_r;
                end
                cnt_compare <= cnt_compare + 1'b1;
            end

            4'd1: begin
                if (delay2_ps_r >= max_delay_ps) begin
                    max_delay_ps <= delay2_ps_r;
                end
                else if (delay2_ps_r <= min_delay_ps) begin
                    min_delay_ps <= delay2_ps_r;
                end
                cnt_compare <= cnt_compare + 1'b1;
            end

            4'd2: begin
                if (delay3_ps_r >= max_delay_ps) begin
                    max_delay_ps <= delay3_ps_r;
                end
                else if (delay3_ps_r <= min_delay_ps) begin
                    min_delay_ps <= delay3_ps_r;
                end
                cnt_compare <= cnt_compare + 1'b1;
            end

            4'd3: begin
                    skew        <= max_delay_ps - min_delay_ps;
                    cnt_compare <= cnt_compare + 1'b1;
                end
            4'd4:begin
                if(skew>=2500)
                    skew_flag<=1;
                   else
                    skew_flag<=0;
                cnt_compare <= cnt_compare + 1'b1;
                end

            4'd5: begin
                max_delay_reg <= max_delay_ps;
                cnt_compare   <= cnt_compare + 1'b1;
            end

            4'd6: begin
                diff_ps[0]  <= max_delay_reg - delay0_ps_r;
                cnt_compare <= cnt_compare + 1'b1;
            end

            4'd7: begin
                diff_ps[1]  <= max_delay_reg - delay1_ps_r;
                cnt_compare <= cnt_compare + 1'b1;
            end

            4'd8: begin
                diff_ps[2]  <= max_delay_reg - delay2_ps_r;
                cnt_compare <= cnt_compare + 1'b1;
            end

            4'd9: begin
                diff_ps[3]  <= max_delay_reg - delay3_ps_r;
                cnt_compare <= cnt_compare + 1'b1;
            end

            4'd10: begin
                compare_finish <= 1'b1;
            end

            default: begin
                cnt_compare <= cnt_compare;
            end

        endcase
    end
end

    reg [3:0]   state1          ;
    reg [3:0]   state2          ;
    reg [4:0]   delay_count_r0  ;
    reg [4:0]   delay_count_r1  ;
    reg [4:0]   delay_count_r2  ;
    reg [4:0]   delay_count_r3  ;
    reg [31:0]  data_reg0       ;
    reg [31:0]  data_reg1       ;
    reg [31:0]  data_reg2       ;
    reg [31:0]  data_reg3       ;
    reg [16:0]  max_coarse      ;
    always @(posedge clk_200m or negedge rst_n) begin
        if (!rst_n)begin
            direct_mode         <=0;
            delay_count0        <=0;
            delay_count1        <=0;
            delay_count2        <=0;
            delay_count3        <=0;
            state1              <=0;
            state2              <=0;
            delay_count_r0      <=0;
            delay_count_r1      <=0;
            delay_count_r2      <=0;
            delay_count_r3      <=0; 
            data_reg0           <=0;
            data_reg1           <=0;
            data_reg2           <=0;
            data_reg3           <=0;    
            max_coarse          <=0;  
            valid_out           <=1'b0;          
            end
        else    if(compare_finish == 1'b1 && skew_flag == 1 && valid_in_reg==1'b1)begin
                    case(state1)
                    0: begin
                        if(coarse0_r2>coarse1_r2)
                            max_coarse<=coarse0_r2;
                        else
                           max_coarse<=coarse1_r2; 
                        state1<=state1+1;
                       end
                    1:begin                    
                       if(coarse2_r2>max_coarse)     
                           max_coarse<=coarse2_r2;
                       else                    
                          max_coarse<=max_coarse; 
                       state1<=state1+1;         
                      end                      

                     2:begin                    
                       if(coarse3_r2>max_coarse)     
                           max_coarse<=coarse3;
                       else                    
                          max_coarse<=max_coarse; 
                       state1<=state1+1;         
                      end    
                            
                      3:  begin
                              if(max_coarse-coarse0_r2>=MAX_DELAY_COARSE)
                                 delay_count_r0<=MAX_DELAY_COARSE;
                              else
                                 delay_count_r0<=max_coarse-coarse0_r2;                         
                              state1<=state1+1;                
                          end   
                          
                      4:  begin                                           
                              if(max_coarse-coarse1_r2>=MAX_DELAY_COARSE)    
                                 delay_count_r1<=MAX_DELAY_COARSE;                         
                              else                                        
                                 delay_count_r1<=max_coarse-coarse1_r2;        
                              state1<=state1+1;                           
                          end
                          
                      5:  begin                                       
                              if(max_coarse-coarse2_r2>=MAX_DELAY_COARSE)
                                 delay_count_r2<=MAX_DELAY_COARSE;                     
                              else                                                                                 
                                 delay_count_r2<=max_coarse-coarse2_r2;        
                              state1<=state1+1;                           
                          end 
                        
                      6:  begin                                          
                              if(max_coarse-coarse3_r2>=MAX_DELAY_COARSE)   
                                 delay_count_r3<=MAX_DELAY_COARSE;                        
                              else                                       
                                 delay_count_r3<=max_coarse-coarse3_r2;       
                              state1<=state1+1;                          
                          end                                            
                                                                      
                       
                      7:begin      delay_count0<=delay_count_r0;state1<=state1+1;end
                      8:begin      delay_count1<=delay_count_r1;state1<=state1+1;end     
                      9:begin      delay_count2<=delay_count_r2;state1<=state1+1;end       
                      10:begin     delay_count3<=delay_count_r3;state1<=state1+1;end   
                      11:begin
                            valid_out<=1;
                            direct_mode         <=0;
                         end                             
                   endcase
                   end
       else
             if(compare_finish== 1'b1 && skew_flag == 0 &&  valid_in_reg==1'b1)
                case(state2)
                    0:begin
                      data_reg0     <=diff_ps[0];
                      data_reg1     <=diff_ps[1];
                      data_reg2     <=diff_ps[2];
                      data_reg3     <=diff_ps[3];
                      state2<=4'd1;                        
                      end
                    1:if(delay_count_r0==31)              
                        state2<=state2+1;             
                      else  if(data_reg0>78)begin 
                        data_reg0<=data_reg0-78;
                        delay_count_r0<=delay_count_r0+1;end
                      else                            
                        begin                         
                            state2<=4'd2;         
                        end 
                        
                     2:if(delay_count_r1==31)                 
                         state2<=state2+1;          
                       else  if(data_reg1>78)begin   
                         data_reg1<=data_reg1-78;      
                         delay_count_r1<=delay_count_r1+1;end            
                       else                          
                         begin                       
                             state2<=4'd3;       
                         end                         
                         
                     3:if(delay_count_r2==31)                   
                         state2<=state2+1;            
                       else  if(data_reg2>78)begin     
                         data_reg2<=data_reg2-78;       
                         delay_count_r2<=delay_count_r2+1;end             
                       else                           
                         begin                        
                             state2<=4'd4;        
                         end                          
                         
                     4:if(delay_count_r3==31)                  
                         state2<=state2+1;           
                       else  if(data_reg3>78)begin    
                         data_reg3<=data_reg3-78;      
                         delay_count_r3<=delay_count_r3+1;end            
                       else                          
                         begin                       
                             state2<=4'd5;       
                         end  
                     5:begin
                        direct_mode<=1;  
                        delay_count0<=delay_count_r0;
                        delay_count1<=delay_count_r1;
                        delay_count2<=delay_count_r2;
                        delay_count3<=delay_count_r3;
                        valid_out<=1;
                       end
                                                        
                endcase     
        end
  rs232 #(
    .UART_BPS          (9600),
    .CLK_FREQ          (200_000_000),
    .SEND_INTERVAL_SEC (3)
)
u_rs232 (
    .sys_clk   (clk_200m),
    .sys_rst_n (rst_n&&locked),

    .data0     (delay0_ps_r),
    .data1     (delay1_ps_r),
    .data2     (delay2_ps_r),
    .data3     (delay3_ps_r),

    .tx        (uart_tx)
);

endmodule
