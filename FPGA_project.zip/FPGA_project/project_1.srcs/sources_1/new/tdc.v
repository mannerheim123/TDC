`timescale 1ns / 1ps

module tdc #(
    parameter integer CARRY4_NUM = 38,
    parameter integer TAP_NUM    = CARRY4_NUM * 4
)(
    input  wire        clk_400m,
    input  wire        rst_n,

    input  wire        start,
    input  wire [3:0]  stop,

    output reg  [15:0] coarse0,
    output reg  [15:0] coarse1,
    output reg  [15:0] coarse2,
    output reg  [15:0] coarse3,

    output reg  [8:0]  tap0,
    output reg  [8:0]  tap1,
    output reg  [8:0]  tap2,
    output reg  [8:0]  tap3,

    output reg         valid,

    output wire        fan_pwm
);

assign fan_pwm = 1'b0;

// ============================================================================
// 1. stop ͬ���������ؼ��
// ע�⣺stop_rise ��� stop ��һ�α� clk_400m �ɵ��ߵ�ƽ��һ�ġ�
// ��˺���Ҫ������һ�ĵ� carry_samp / coarse_samp��
// ============================================================================

reg [3:0] stop_d1;
reg [3:0] stop_d2;

wire [3:0] stop_rise;

assign stop_rise = stop_d1 & ~stop_d2;

always @(posedge clk_400m or negedge rst_n) begin
    if(!rst_n) begin
        stop_d1 <= 4'b0000;
        stop_d2 <= 4'b0000;
    end
    else if(!start) begin
        stop_d1 <= 4'b0000;
        stop_d2 <= 4'b0000;
    end
    else begin
        stop_d1 <= stop;
        stop_d2 <= stop_d1;
    end
end

// ============================================================================
// 2. �ּ�����
// start Ϊ�ߺ�ʼ������start ���ͺ����¿�ʼһ�β�����
// ============================================================================

reg [15:0] coarse_cnt;

always @(posedge clk_400m or negedge rst_n) begin
    if(!rst_n) begin
        coarse_cnt <= 16'd0;
    end
    else if(!start) begin
        coarse_cnt <= 16'd0;
    end
    else begin
        coarse_cnt <= coarse_cnt + 1'b1;
    end
end

// ============================================================================
// 3. ��· CARRY4 �ӳ���
// ============================================================================

(* keep = "true" *) wire [TAP_NUM-1:0] carry0;
(* keep = "true" *) wire [TAP_NUM-1:0] carry1;
(* keep = "true" *) wire [TAP_NUM-1:0] carry2;
(* keep = "true" *) wire [TAP_NUM-1:0] carry3;

wire [CARRY4_NUM:0] ci0;
wire [CARRY4_NUM:0] ci1;
wire [CARRY4_NUM:0] ci2;
wire [CARRY4_NUM:0] ci3;

assign ci0[0] = 1'b0;
assign ci1[0] = 1'b0;
assign ci2[0] = 1'b0;
assign ci3[0] = 1'b0;

genvar i;

// ----------------------------
// channel 0
// ----------------------------
generate
    for(i = 0; i < CARRY4_NUM; i = i + 1) begin : GEN_CARRY0
        wire [3:0] co_w;

        (* DONT_TOUCH = "TRUE" *)
        CARRY4 u_carry0 (
            .CO     (co_w),
            .O      (),
            .CI     (ci0[i]),
            .CYINIT ((i == 0) ? stop[0] : 1'b0),
            .DI     (4'b0000),
            .S      (4'b1111)
        );

        assign carry0[i*4 + 0] = co_w[0];
        assign carry0[i*4 + 1] = co_w[1];
        assign carry0[i*4 + 2] = co_w[2];
        assign carry0[i*4 + 3] = co_w[3];
        assign ci0[i+1]        = co_w[3];
    end
endgenerate

// ----------------------------
// channel 1
// ----------------------------
generate
    for(i = 0; i < CARRY4_NUM; i = i + 1) begin : GEN_CARRY1
        wire [3:0] co_w;

        (* DONT_TOUCH = "TRUE" *)
        CARRY4 u_carry1 (
            .CO     (co_w),
            .O      (),
            .CI     (ci1[i]),
            .CYINIT ((i == 0) ? stop[1] : 1'b0),
            .DI     (4'b0000),
            .S      (4'b1111)
        );

        assign carry1[i*4 + 0] = co_w[0];
        assign carry1[i*4 + 1] = co_w[1];
        assign carry1[i*4 + 2] = co_w[2];
        assign carry1[i*4 + 3] = co_w[3];
        assign ci1[i+1]        = co_w[3];
    end
endgenerate

// ----------------------------
// channel 2
// ----------------------------
generate
    for(i = 0; i < CARRY4_NUM; i = i + 1) begin : GEN_CARRY2
        wire [3:0] co_w;

        (* DONT_TOUCH = "TRUE" *)
        CARRY4 u_carry2 (
            .CO     (co_w),
            .O      (),
            .CI     (ci2[i]),
            .CYINIT ((i == 0) ? stop[2] : 1'b0),
            .DI     (4'b0000),
            .S      (4'b1111)
        );

        assign carry2[i*4 + 0] = co_w[0];
        assign carry2[i*4 + 1] = co_w[1];
        assign carry2[i*4 + 2] = co_w[2];
        assign carry2[i*4 + 3] = co_w[3];
        assign ci2[i+1]        = co_w[3];
    end
endgenerate

// ----------------------------
// channel 3
// ----------------------------
generate
    for(i = 0; i < CARRY4_NUM; i = i + 1) begin : GEN_CARRY3
        wire [3:0] co_w;

        (* DONT_TOUCH = "TRUE" *)
        CARRY4 u_carry3 (
            .CO     (co_w),
            .O      (),
            .CI     (ci3[i]),
            .CYINIT ((i == 0) ? stop[3] : 1'b0),
            .DI     (4'b0000),
            .S      (4'b1111)
        );

        assign carry3[i*4 + 0] = co_w[0];
        assign carry3[i*4 + 1] = co_w[1];
        assign carry3[i*4 + 2] = co_w[2];
        assign carry3[i*4 + 3] = co_w[3];
        assign ci3[i+1]        = co_w[3];
    end
endgenerate

// ============================================================================
// 4. ÿ�� clk_400m ������һ�� carry �� coarse
// ��һ������ TDC �Ĺؼ���
// stop �����ط�������һ��ʱ���ػ�ɵ� carry ͼ����
// stop_rise ��һ�ĳ��֣����Բ���ʱʹ����һ�ĵ� carry_samp��
// ============================================================================

reg [TAP_NUM-1:0] carry0_samp;
reg [TAP_NUM-1:0] carry1_samp;
reg [TAP_NUM-1:0] carry2_samp;
reg [TAP_NUM-1:0] carry3_samp;

reg [15:0] coarse_samp;

always @(posedge clk_400m or negedge rst_n) begin
    if(!rst_n) begin
        carry0_samp <= {TAP_NUM{1'b0}};
        carry1_samp <= {TAP_NUM{1'b0}};
        carry2_samp <= {TAP_NUM{1'b0}};
        carry3_samp <= {TAP_NUM{1'b0}};
        coarse_samp <= 16'd0;
    end
    else if(!start) begin
        carry0_samp <= {TAP_NUM{1'b0}};
        carry1_samp <= {TAP_NUM{1'b0}};
        carry2_samp <= {TAP_NUM{1'b0}};
        carry3_samp <= {TAP_NUM{1'b0}};
        coarse_samp <= 16'd0;
    end
    else begin
        carry0_samp <= carry0;
        carry1_samp <= carry1;
        carry2_samp <= carry2;
        carry3_samp <= carry3;
        coarse_samp <= coarse_cnt;
    end
end

// ============================================================================
// 5. ���� stop ��һ�������ض�Ӧ�� coarse �� carry ͼ��
// ֻҪ stop_rise ���֣���������һ�ĵ� carry_samp��
// ============================================================================

reg [TAP_NUM-1:0] carry0_r;
reg [TAP_NUM-1:0] carry1_r;
reg [TAP_NUM-1:0] carry2_r;
reg [TAP_NUM-1:0] carry3_r;

reg [3:0] captured;

always @(posedge clk_400m or negedge rst_n) begin
    if(!rst_n) begin
        carry0_r <= {TAP_NUM{1'b0}};
        carry1_r <= {TAP_NUM{1'b0}};
        carry2_r <= {TAP_NUM{1'b0}};
        carry3_r <= {TAP_NUM{1'b0}};

        coarse0 <= 16'd0;
        coarse1 <= 16'd0;
        coarse2 <= 16'd0;
        coarse3 <= 16'd0;

        captured <= 4'b0000;
    end
    else if(!start) begin
        carry0_r <= {TAP_NUM{1'b0}};
        carry1_r <= {TAP_NUM{1'b0}};
        carry2_r <= {TAP_NUM{1'b0}};
        carry3_r <= {TAP_NUM{1'b0}};

        coarse0 <= 16'd0;
        coarse1 <= 16'd0;
        coarse2 <= 16'd0;
        coarse3 <= 16'd0;

        captured <= 4'b0000;
    end
    else begin
        if(stop_rise[0] && !captured[0]) begin
            carry0_r    <= carry0_samp;
            coarse0     <= coarse_samp;
            captured[0] <= 1'b1;
        end

        if(stop_rise[1] && !captured[1]) begin
            carry1_r    <= carry1_samp;
            coarse1     <= coarse_samp;
            captured[1] <= 1'b1;
        end

        if(stop_rise[2] && !captured[2]) begin
            carry2_r    <= carry2_samp;
            coarse2     <= coarse_samp;
            captured[2] <= 1'b1;
        end

        if(stop_rise[3] && !captured[3]) begin
            carry3_r    <= carry3_samp;
            coarse3     <= coarse_samp;
            captured[3] <= 1'b1;
        end
    end
end

// ============================================================================
// 6. ɨ�� carry_r��ͳ�� tap
// ÿ��ͳ�� 4 bit����Ӧһ�� CARRY4 �� 4 �� CO �����
// ============================================================================

localparam [3:0] S_WAIT_ALL = 4'd0;
localparam [3:0] S_LOAD0    = 4'd1;
localparam [3:0] S_SCAN0    = 4'd2;
localparam [3:0] S_LOAD1    = 4'd3;
localparam [3:0] S_SCAN1    = 4'd4;
localparam [3:0] S_LOAD2    = 4'd5;
localparam [3:0] S_SCAN2    = 4'd6;
localparam [3:0] S_LOAD3    = 4'd7;
localparam [3:0] S_SCAN3    = 4'd8;
localparam [3:0] S_DONE     = 4'd9;

reg [3:0] state;

reg [TAP_NUM-1:0] scan_reg;
reg [8:0]         scan_blk_cnt;
reg [8:0]         tap_acc;

wire [2:0] scan_add;

assign scan_add = scan_reg[0] + scan_reg[1] + scan_reg[2] + scan_reg[3];

always @(posedge clk_400m or negedge rst_n) begin
    if(!rst_n) begin
        state        <= S_WAIT_ALL;
        scan_reg     <= {TAP_NUM{1'b0}};
        scan_blk_cnt <= 9'd0;
        tap_acc      <= 9'd0;

        tap0         <= 9'd0;
        tap1         <= 9'd0;
        tap2         <= 9'd0;
        tap3         <= 9'd0;

        valid        <= 1'b0;
    end
    else if(!start) begin
        state        <= S_WAIT_ALL;
        scan_reg     <= {TAP_NUM{1'b0}};
        scan_blk_cnt <= 9'd0;
        tap_acc      <= 9'd0;

        tap0         <= 9'd0;
        tap1         <= 9'd0;
        tap2         <= 9'd0;
        tap3         <= 9'd0;

        valid        <= 1'b0;
    end
    else begin
        case(state)

            S_WAIT_ALL: begin
                valid <= 1'b0;

                if(captured == 4'b1111) begin
                    state <= S_LOAD0;
                end
            end

            S_LOAD0: begin
                scan_reg     <= carry0_r;
                scan_blk_cnt <= 9'd0;
                tap_acc      <= 9'd0;
                tap0         <= 9'd0;
                state        <= S_SCAN0;
            end

            S_SCAN0: begin
                tap_acc  <= tap_acc + scan_add;
                scan_reg <= {{4{1'b0}}, scan_reg[TAP_NUM-1:4]};

                if(scan_blk_cnt == CARRY4_NUM - 1) begin
                    tap0         <= tap_acc + scan_add;
                    scan_blk_cnt <= 9'd0;
                    state        <= S_LOAD1;
                end
                else begin
                    scan_blk_cnt <= scan_blk_cnt + 1'b1;
                end
            end

            S_LOAD1: begin
                scan_reg     <= carry1_r;
                scan_blk_cnt <= 9'd0;
                tap_acc      <= 9'd0;
                tap1         <= 9'd0;
                state        <= S_SCAN1;
            end

            S_SCAN1: begin
                tap_acc  <= tap_acc + scan_add;
                scan_reg <= {{4{1'b0}}, scan_reg[TAP_NUM-1:4]};

                if(scan_blk_cnt == CARRY4_NUM - 1) begin
                    tap1         <= tap_acc + scan_add;
                    scan_blk_cnt <= 9'd0;
                    state        <= S_LOAD2;
                end
                else begin
                    scan_blk_cnt <= scan_blk_cnt + 1'b1;
                end
            end

            S_LOAD2: begin
                scan_reg     <= carry2_r;
                scan_blk_cnt <= 9'd0;
                tap_acc      <= 9'd0;
                tap2         <= 9'd0;
                state        <= S_SCAN2;
            end

            S_SCAN2: begin
                tap_acc  <= tap_acc + scan_add;
                scan_reg <= {{4{1'b0}}, scan_reg[TAP_NUM-1:4]};

                if(scan_blk_cnt == CARRY4_NUM - 1) begin
                    tap2         <= tap_acc + scan_add;
                    scan_blk_cnt <= 9'd0;
                    state        <= S_LOAD3;
                end
                else begin
                    scan_blk_cnt <= scan_blk_cnt + 1'b1;
                end
            end

            S_LOAD3: begin
                scan_reg     <= carry3_r;
                scan_blk_cnt <= 9'd0;
                tap_acc      <= 9'd0;
                tap3         <= 9'd0;
                state        <= S_SCAN3;
            end

            S_SCAN3: begin
                tap_acc  <= tap_acc + scan_add;
                scan_reg <= {{4{1'b0}}, scan_reg[TAP_NUM-1:4]};

                if(scan_blk_cnt == CARRY4_NUM - 1) begin
                    tap3         <= tap_acc + scan_add;
                    scan_blk_cnt <= 9'd0;
                    state        <= S_DONE;
                end
                else begin
                    scan_blk_cnt <= scan_blk_cnt + 1'b1;
                end
            end

            S_DONE: begin
                valid <= 1'b1;
                state <= S_DONE;
            end

            default: begin
                state <= S_WAIT_ALL;
            end

        endcase
    end
end

endmodule