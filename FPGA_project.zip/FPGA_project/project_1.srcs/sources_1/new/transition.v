module transition
(
    input wire        clk_200m,
    input wire        rst_n,
    input wire [15:0] coarse0   ,
    input wire [15:0] coarse1   ,
    input wire [15:0] coarse2   ,
    input wire [15:0] coarse3   ,            
    input wire [8:0]  tap0      , 
    input wire [8:0]  tap1      , 
    input wire [8:0]  tap2      , 
    input wire [8:0]  tap3      , 
    input wire       valid      ,
    
    output reg [15:0] coarse0_out  ,
    output reg [15:0] coarse1_out  ,
    output reg [15:0] coarse2_out  ,
    output reg [15:0] coarse3_out  ,
    output reg [8:0]  tap0_out     , 
    output reg [8:0]  tap1_out     , 
    output reg [8:0]  tap2_out     , 
    output reg [8:0]  tap3_out     , 
    output reg        valid_out   
);
reg   [4:0] state;
always @(posedge clk_200m or negedge rst_n)
    if(!rst_n)
    begin
        coarse0_out <=0;
        coarse1_out <=0;
        coarse2_out <=0;
        coarse3_out <=0;
        tap0_out    <=0;
        tap1_out    <=0;
        tap2_out    <=0;
        tap3_out    <=0;
        valid_out   <=0;
    end
    else    if(valid==1)
        begin
        coarse0_out<=coarse0;
        coarse1_out<=coarse1;
        coarse2_out<=coarse2;
        coarse3_out<=coarse3;
        tap0_out   <=tap0   ;
        tap1_out   <=tap1   ;
        tap2_out   <=tap2   ;
        tap3_out   <=tap3   ;
        valid_out  <=1;
        end
        
endmodule
