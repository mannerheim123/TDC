# -----------------------------
# Clock
# -----------------------------
create_clock -period 5.000 [get_ports clk_200m_p]
set_property PACKAGE_PIN AE10 [get_ports clk_200m_p]
set_property IOSTANDARD DIFF_SSTL15 [get_ports clk_200m_p]

# -----------------------------
# Inputs
# -----------------------------
set_property PACKAGE_PIN M28 [get_ports {sig_in[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {sig_in[3]}]

set_property PACKAGE_PIN J21 [get_ports {sig_in[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {sig_in[0]}]

set_property PACKAGE_PIN K26 [get_ports {sig_in[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {sig_in[1]}]

set_property PACKAGE_PIN L30 [get_ports {sig_in[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {sig_in[2]}]

set_property PACKAGE_PIN J23 [get_ports start]
set_property IOSTANDARD LVCMOS33 [get_ports start]

set_property PACKAGE_PIN AG27 [get_ports rst_n]
set_property IOSTANDARD LVCMOS25 [get_ports rst_n]

# -----------------------------
# Outputs
# -----------------------------
set_property PACKAGE_PIN L26 [get_ports {sig_sync[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {sig_sync[2]}]

set_property PACKAGE_PIN N27 [get_ports {sig_sync[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {sig_sync[0]}]

set_property PACKAGE_PIN J27 [get_ports {sig_sync[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {sig_sync[3]}]

set_property PACKAGE_PIN N29 [get_ports {sig_sync[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {sig_sync[1]}]

set_property PACKAGE_PIN J29 [get_ports align_valid]
set_property IOSTANDARD LVCMOS33 [get_ports align_valid]

set_property PACKAGE_PIN L22 [get_ports {gen_signal[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {gen_signal[0]}]

set_property PACKAGE_PIN K23 [get_ports {gen_signal[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {gen_signal[1]}]

set_property PACKAGE_PIN L25 [get_ports {gen_signal[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {gen_signal[2]}]

set_property PACKAGE_PIN M29 [get_ports {gen_signal[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {gen_signal[3]}]

set_property PACKAGE_PIN L21 [get_ports gen_start]
set_property IOSTANDARD LVCMOS33 [get_ports gen_start]

set_property PACKAGE_PIN AK26 [get_ports uart_tx]
set_property IOSTANDARD LVCMOS25 [get_ports uart_tx]

set_property IOSTANDARD LVCMOS25 [get_ports fan_pwm]
set_property PACKAGE_PIN AE26 [get_ports fan_pwm]
