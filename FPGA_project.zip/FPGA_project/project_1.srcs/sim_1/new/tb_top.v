`timescale 1ns / 1ps

module tb_top_large_simple;

    reg clk_200m_p;
    reg clk_200m_n;
    reg rst_n;
    reg start;

    reg [3:0] sig_in;

    wire        gen_start;
    wire [3:0]  gen_signal;
    wire [3:0]  sig_sync;
    wire        align_valid;
    wire        uart_tx;
    wire        fan_pwm;

    top uut (
        .clk_200m_p  (clk_200m_p),
        .clk_200m_n  (clk_200m_n),
        .rst_n       (rst_n),
        .start       (start),
        .sig_in      (sig_in),

        .gen_start   (gen_start),
        .gen_signal  (gen_signal),
        .sig_sync    (sig_sync),
        .align_valid (align_valid),
        .uart_tx     (uart_tx),
        .fan_pwm     (fan_pwm)
    );

    // 200 MHz differential clock
    initial begin
        clk_200m_p = 1'b0;
        clk_200m_n = 1'b1;
        forever begin
            #2.5;
            clk_200m_p = ~clk_200m_p;
            clk_200m_n = ~clk_200m_n;
        end
    end

    // reset and start
    initial begin
        rst_n  = 1'b0;
        start  = 1'b0;
        sig_in = 4'b0000;

        #1000;
        rst_n = 1'b1;

        // wait for PLL / IDELAYCTRL
        #3000;

        start = 1'b1;
    end

    // sig_in[0]: first rising edge after start + 100 ns
    initial begin
        sig_in[0] = 1'b0;
        #4100;
        forever begin
            sig_in[0] = 1'b1;
            #25;
            sig_in[0] = 1'b0;
            #25;
        end
    end

    // sig_in[1]: first rising edge after start + 105 ns
    initial begin
        sig_in[1] = 1'b0;
        #4105;
        forever begin
            sig_in[1] = 1'b1;
            #25;
            sig_in[1] = 1'b0;
            #25;
        end
    end

    // sig_in[2]: first rising edge after start + 110 ns
    initial begin
        sig_in[2] = 1'b0;
        #4110;
        forever begin
            sig_in[2] = 1'b1;
            #25;
            sig_in[2] = 1'b0;
            #25;
        end
    end

    // sig_in[3]: first rising edge after start + 115 ns
    initial begin
        sig_in[3] = 1'b0;
        #4115;
        forever begin
            sig_in[3] = 1'b1;
            #25;
            sig_in[3] = 1'b0;
            #25;
        end
    end

    // print result
    always @(posedge clk_200m_p) begin
        if (align_valid) begin
            $display("time=%0t sig_in=%b sig_sync=%b",
                     $time, sig_in, sig_sync);
        end
    end

    initial begin
        #50000;
        $stop;
    end

endmodule