`timescale 1ps / 1ps

module tb_top_small;

    reg clk_400m;
    reg rst_n;

    reg [3:0] sig_in;

    reg [4:0] delay_count0;
    reg [4:0] delay_count1;
    reg [4:0] delay_count2;
    reg [4:0] delay_count3;

    reg direct_mode;
    reg valid;

    wire [3:0] sig_sync;
    wire       align_valid;

    delay_idelay78_sim uut (
        .clk_400m     (clk_400m),
        .rst_n        (rst_n),

        .sig_in       (sig_in),

        .delay_count0 (delay_count0),
        .delay_count1 (delay_count1),
        .delay_count2 (delay_count2),
        .delay_count3 (delay_count3),

        .direct_mode  (direct_mode),
        .valid        (valid),

        .sig_sync     (sig_sync),
        .align_valid  (align_valid)
    );

    // 400 MHz clock, period = 2500 ps
    initial begin
        clk_400m = 1'b0;
        forever begin
            #1250;
            clk_400m = ~clk_400m;
        end
    end

    initial begin
        $timeformat(-12, 0, " ps", 10);

        rst_n = 1'b0;
        sig_in = 4'b0000;

        delay_count0 = 5'd0;
        delay_count1 = 5'd0;
        delay_count2 = 5'd0;
        delay_count3 = 5'd0;

        direct_mode = 1'b0;
        valid = 1'b0;

        #10000;
        rst_n = 1'b1;

        #10000;

        // Small-range mode
        direct_mode = 1'b1;

        // Expected delay:
        // sig_sync[0] = 0 * 78 ps =   0 ps
        // sig_sync[1] = 1 * 78 ps =  78 ps
        // sig_sync[2] = 2 * 78 ps = 156 ps
        // sig_sync[3] = 3 * 78 ps = 234 ps
        delay_count0 = 5'd0;
        delay_count1 = 5'd1;
        delay_count2 = 5'd2;
        delay_count3 = 5'd3;

        valid = 1'b1;
        #2500;
        valid = 1'b0;

        #10000;

        $display("============================================================");
        $display("Input rising edge 1");
        $display("Expected output edge difference:");
        $display("sig_sync[1] - sig_sync[0] =  78 ps");
        $display("sig_sync[2] - sig_sync[0] = 156 ps");
        $display("sig_sync[3] - sig_sync[0] = 234 ps");
        $display("============================================================");

        sig_in = 4'b1111;

        #10000;
        sig_in = 4'b0000;

        #10000;

        $display("============================================================");
        $display("Input rising edge 2");
        $display("============================================================");

        sig_in = 4'b1111;

        #10000;
        sig_in = 4'b0000;

        #10000;
        $stop;
    end

    real t0;
    real t1;
    real t2;
    real t3;

    integer got0;
    integer got1;
    integer got2;
    integer got3;

    initial begin
        t0 = 0.0;
        t1 = 0.0;
        t2 = 0.0;
        t3 = 0.0;

        got0 = 0;
        got1 = 0;
        got2 = 0;
        got3 = 0;
    end

    always @(posedge sig_sync[0]) begin
        if (align_valid) begin
            t0 = $realtime;
            got0 = 1;
            check_edges;
        end
    end

    always @(posedge sig_sync[1]) begin
        if (align_valid) begin
            t1 = $realtime;
            got1 = 1;
            check_edges;
        end
    end

    always @(posedge sig_sync[2]) begin
        if (align_valid) begin
            t2 = $realtime;
            got2 = 1;
            check_edges;
        end
    end

    always @(posedge sig_sync[3]) begin
        if (align_valid) begin
            t3 = $realtime;
            got3 = 1;
            check_edges;
        end
    end

    task check_edges;
        begin
            if (got0 && got1 && got2 && got3) begin
                $display("------------------------------------------------------------");
                $display("sig_sync rising edge time:");
                $display("t0 = %0.0f ps", t0);
                $display("t1 = %0.0f ps", t1);
                $display("t2 = %0.0f ps", t2);
                $display("t3 = %0.0f ps", t3);

                $display("edge difference:");
                $display("t1 - t0 = %0.0f ps", t1 - t0);
                $display("t2 - t0 = %0.0f ps", t2 - t0);
                $display("t3 - t0 = %0.0f ps", t3 - t0);
                $display("------------------------------------------------------------");

                got0 = 0;
                got1 = 0;
                got2 = 0;
                got3 = 0;
            end
        end
    endtask

endmodule


module delay_idelay78_sim #(
    parameter integer IODELAY_TAP_PS = 78,
    parameter integer COARSE_DEPTH   = 30
)(
    input  wire       clk_400m,
    input  wire       rst_n,

    input  wire [3:0] sig_in,

    input  wire [4:0] delay_count0,
    input  wire [4:0] delay_count1,
    input  wire [4:0] delay_count2,
    input  wire [4:0] delay_count3,

    input  wire       direct_mode,
    input  wire       valid,

    output wire [3:0] sig_sync,
    output reg        align_valid
);

    reg [4:0] tap0;
    reg [4:0] tap1;
    reg [4:0] tap2;
    reg [4:0] tap3;

    reg [4:0] coarse_cnt0;
    reg [4:0] coarse_cnt1;
    reg [4:0] coarse_cnt2;
    reg [4:0] coarse_cnt3;

    reg mode_r;
    reg load_finish;

    always @(posedge clk_400m or negedge rst_n) begin
        if (!rst_n) begin
            tap0        <= 5'd0;
            tap1        <= 5'd0;
            tap2        <= 5'd0;
            tap3        <= 5'd0;

            coarse_cnt0 <= 5'd0;
            coarse_cnt1 <= 5'd0;
            coarse_cnt2 <= 5'd0;
            coarse_cnt3 <= 5'd0;

            mode_r      <= 1'b0;
            load_finish <= 1'b0;
            align_valid <= 1'b0;
        end
        else begin
            if (valid) begin
                mode_r <= direct_mode;

                tap0 <= delay_count0;
                tap1 <= delay_count1;
                tap2 <= delay_count2;
                tap3 <= delay_count3;

                coarse_cnt0 <= delay_count0;
                coarse_cnt1 <= delay_count1;
                coarse_cnt2 <= delay_count2;
                coarse_cnt3 <= delay_count3;

                load_finish <= 1'b1;
                align_valid <= 1'b1;
            end
        end
    end

    // Manual IDELAY model: 78 ps per tap
    reg [3:0] sig_idelay;

    always @(sig_in[0]) begin
        sig_idelay[0] <= #(tap0 * IODELAY_TAP_PS) sig_in[0];
    end

    always @(sig_in[1]) begin
        sig_idelay[1] <= #(tap1 * IODELAY_TAP_PS) sig_in[1];
    end

    always @(sig_in[2]) begin
        sig_idelay[2] <= #(tap2 * IODELAY_TAP_PS) sig_in[2];
    end

    always @(sig_in[3]) begin
        sig_idelay[3] <= #(tap3 * IODELAY_TAP_PS) sig_in[3];
    end

    // Simple coarse delay model
    reg [COARSE_DEPTH:0] fifo0;
    reg [COARSE_DEPTH:0] fifo1;
    reg [COARSE_DEPTH:0] fifo2;
    reg [COARSE_DEPTH:0] fifo3;

    always @(posedge clk_400m or negedge rst_n) begin
        if (!rst_n) begin
            fifo0 <= {COARSE_DEPTH+1{1'b0}};
            fifo1 <= {COARSE_DEPTH+1{1'b0}};
            fifo2 <= {COARSE_DEPTH+1{1'b0}};
            fifo3 <= {COARSE_DEPTH+1{1'b0}};
        end
        else begin
            fifo0 <= {fifo0[COARSE_DEPTH-1:0], sig_in[0]};
            fifo1 <= {fifo1[COARSE_DEPTH-1:0], sig_in[1]};
            fifo2 <= {fifo2[COARSE_DEPTH-1:0], sig_in[2]};
            fifo3 <= {fifo3[COARSE_DEPTH-1:0], sig_in[3]};
        end
    end

    wire [3:0] coarse_sync;

    assign coarse_sync = {
        fifo3[coarse_cnt3],
        fifo2[coarse_cnt2],
        fifo1[coarse_cnt1],
        fifo0[coarse_cnt0]
    };

    assign sig_sync = (!load_finish) ? 4'b0000 :
                      (mode_r)       ? sig_idelay :
                                       coarse_sync;

endmodule`timescale 1ps / 1ps

module tb_top_small;

    reg clk_400m;
    reg rst_n;

    reg [3:0] sig_in;

    reg [4:0] delay_count0;
    reg [4:0] delay_count1;
    reg [4:0] delay_count2;
    reg [4:0] delay_count3;

    reg direct_mode;
    reg valid;

    wire [3:0] sig_sync;
    wire       align_valid;

    delay_idelay78_sim uut (
        .clk_400m     (clk_400m),
        .rst_n        (rst_n),

        .sig_in       (sig_in),

        .delay_count0 (delay_count0),
        .delay_count1 (delay_count1),
        .delay_count2 (delay_count2),
        .delay_count3 (delay_count3),

        .direct_mode  (direct_mode),
        .valid        (valid),

        .sig_sync     (sig_sync),
        .align_valid  (align_valid)
    );

    // 400 MHz clock, period = 2500 ps
    initial begin
        clk_400m = 1'b0;
        forever begin
            #1250;
            clk_400m = ~clk_400m;
        end
    end

    initial begin
        $timeformat(-12, 0, " ps", 10);

        rst_n = 1'b0;
        sig_in = 4'b0000;

        delay_count0 = 5'd0;
        delay_count1 = 5'd0;
        delay_count2 = 5'd0;
        delay_count3 = 5'd0;

        direct_mode = 1'b0;
        valid = 1'b0;

        #10000;
        rst_n = 1'b1;

        #10000;

        // Small-range mode
        direct_mode = 1'b1;

        // Expected delay:
        // sig_sync[0] = 0 * 78 ps =   0 ps
        // sig_sync[1] = 1 * 78 ps =  78 ps
        // sig_sync[2] = 2 * 78 ps = 156 ps
        // sig_sync[3] = 3 * 78 ps = 234 ps
        delay_count0 = 5'd0;
        delay_count1 = 5'd1;
        delay_count2 = 5'd2;
        delay_count3 = 5'd3;

        valid = 1'b1;
        #2500;
        valid = 1'b0;

        #10000;

        $display("============================================================");
        $display("Input rising edge 1");
        $display("Expected output edge difference:");
        $display("sig_sync[1] - sig_sync[0] =  78 ps");
        $display("sig_sync[2] - sig_sync[0] = 156 ps");
        $display("sig_sync[3] - sig_sync[0] = 234 ps");
        $display("============================================================");

        sig_in = 4'b1111;

        #10000;
        sig_in = 4'b0000;

        #10000;

        $display("============================================================");
        $display("Input rising edge 2");
        $display("============================================================");

        sig_in = 4'b1111;

        #10000;
        sig_in = 4'b0000;

        #10000;
        $stop;
    end

    real t0;
    real t1;
    real t2;
    real t3;

    integer got0;
    integer got1;
    integer got2;
    integer got3;

    initial begin
        t0 = 0.0;
        t1 = 0.0;
        t2 = 0.0;
        t3 = 0.0;

        got0 = 0;
        got1 = 0;
        got2 = 0;
        got3 = 0;
    end

    always @(posedge sig_sync[0]) begin
        if (align_valid) begin
            t0 = $realtime;
            got0 = 1;
            check_edges;
        end
    end

    always @(posedge sig_sync[1]) begin
        if (align_valid) begin
            t1 = $realtime;
            got1 = 1;
            check_edges;
        end
    end

    always @(posedge sig_sync[2]) begin
        if (align_valid) begin
            t2 = $realtime;
            got2 = 1;
            check_edges;
        end
    end

    always @(posedge sig_sync[3]) begin
        if (align_valid) begin
            t3 = $realtime;
            got3 = 1;
            check_edges;
        end
    end

    task check_edges;
        begin
            if (got0 && got1 && got2 && got3) begin
                $display("------------------------------------------------------------");
                $display("sig_sync rising edge time:");
                $display("t0 = %0.0f ps", t0);
                $display("t1 = %0.0f ps", t1);
                $display("t2 = %0.0f ps", t2);
                $display("t3 = %0.0f ps", t3);

                $display("edge difference:");
                $display("t1 - t0 = %0.0f ps", t1 - t0);
                $display("t2 - t0 = %0.0f ps", t2 - t0);
                $display("t3 - t0 = %0.0f ps", t3 - t0);
                $display("------------------------------------------------------------");

                got0 = 0;
                got1 = 0;
                got2 = 0;
                got3 = 0;
            end
        end
    endtask

endmodule


module delay_idelay78_sim #(
    parameter integer IODELAY_TAP_PS = 78,
    parameter integer COARSE_DEPTH   = 30
)(
    input  wire       clk_400m,
    input  wire       rst_n,

    input  wire [3:0] sig_in,

    input  wire [4:0] delay_count0,
    input  wire [4:0] delay_count1,
    input  wire [4:0] delay_count2,
    input  wire [4:0] delay_count3,

    input  wire       direct_mode,
    input  wire       valid,

    output wire [3:0] sig_sync,
    output reg        align_valid
);

    reg [4:0] tap0;
    reg [4:0] tap1;
    reg [4:0] tap2;
    reg [4:0] tap3;

    reg [4:0] coarse_cnt0;
    reg [4:0] coarse_cnt1;
    reg [4:0] coarse_cnt2;
    reg [4:0] coarse_cnt3;

    reg mode_r;
    reg load_finish;

    always @(posedge clk_400m or negedge rst_n) begin
        if (!rst_n) begin
            tap0        <= 5'd0;
            tap1        <= 5'd0;
            tap2        <= 5'd0;
            tap3        <= 5'd0;

            coarse_cnt0 <= 5'd0;
            coarse_cnt1 <= 5'd0;
            coarse_cnt2 <= 5'd0;
            coarse_cnt3 <= 5'd0;

            mode_r      <= 1'b0;
            load_finish <= 1'b0;
            align_valid <= 1'b0;
        end
        else begin
            if (valid) begin
                mode_r <= direct_mode;

                tap0 <= delay_count0;
                tap1 <= delay_count1;
                tap2 <= delay_count2;
                tap3 <= delay_count3;

                coarse_cnt0 <= delay_count0;
                coarse_cnt1 <= delay_count1;
                coarse_cnt2 <= delay_count2;
                coarse_cnt3 <= delay_count3;

                load_finish <= 1'b1;
                align_valid <= 1'b1;
            end
        end
    end

    // Manual IDELAY model: 78 ps per tap
    reg [3:0] sig_idelay;

    always @(sig_in[0]) begin
        sig_idelay[0] <= #(tap0 * IODELAY_TAP_PS) sig_in[0];
    end

    always @(sig_in[1]) begin
        sig_idelay[1] <= #(tap1 * IODELAY_TAP_PS) sig_in[1];
    end

    always @(sig_in[2]) begin
        sig_idelay[2] <= #(tap2 * IODELAY_TAP_PS) sig_in[2];
    end

    always @(sig_in[3]) begin
        sig_idelay[3] <= #(tap3 * IODELAY_TAP_PS) sig_in[3];
    end

    // Simple coarse delay model
    reg [COARSE_DEPTH:0] fifo0;
    reg [COARSE_DEPTH:0] fifo1;
    reg [COARSE_DEPTH:0] fifo2;
    reg [COARSE_DEPTH:0] fifo3;

    always @(posedge clk_400m or negedge rst_n) begin
        if (!rst_n) begin
            fifo0 <= {COARSE_DEPTH+1{1'b0}};
            fifo1 <= {COARSE_DEPTH+1{1'b0}};
            fifo2 <= {COARSE_DEPTH+1{1'b0}};
            fifo3 <= {COARSE_DEPTH+1{1'b0}};
        end
        else begin
            fifo0 <= {fifo0[COARSE_DEPTH-1:0], sig_in[0]};
            fifo1 <= {fifo1[COARSE_DEPTH-1:0], sig_in[1]};
            fifo2 <= {fifo2[COARSE_DEPTH-1:0], sig_in[2]};
            fifo3 <= {fifo3[COARSE_DEPTH-1:0], sig_in[3]};
        end
    end

    wire [3:0] coarse_sync;

    assign coarse_sync = {
        fifo3[coarse_cnt3],
        fifo2[coarse_cnt2],
        fifo1[coarse_cnt1],
        fifo0[coarse_cnt0]
    };

    assign sig_sync = (!load_finish) ? 4'b0000 :
                      (mode_r)       ? sig_idelay :
                                       coarse_sync;

endmodule`timescale 1ps / 1ps

module tb_top_small;

    reg clk_400m;
    reg rst_n;

    reg [3:0] sig_in;

    reg [4:0] delay_count0;
    reg [4:0] delay_count1;
    reg [4:0] delay_count2;
    reg [4:0] delay_count3;

    reg direct_mode;
    reg valid;

    wire [3:0] sig_sync;
    wire       align_valid;

    delay_idelay78_sim uut (
        .clk_400m     (clk_400m),
        .rst_n        (rst_n),

        .sig_in       (sig_in),

        .delay_count0 (delay_count0),
        .delay_count1 (delay_count1),
        .delay_count2 (delay_count2),
        .delay_count3 (delay_count3),

        .direct_mode  (direct_mode),
        .valid        (valid),

        .sig_sync     (sig_sync),
        .align_valid  (align_valid)
    );

    // 400 MHz clock, period = 2500 ps
    initial begin
        clk_400m = 1'b0;
        forever begin
            #1250;
            clk_400m = ~clk_400m;
        end
    end

    initial begin
        $timeformat(-12, 0, " ps", 10);

        rst_n = 1'b0;
        sig_in = 4'b0000;

        delay_count0 = 5'd0;
        delay_count1 = 5'd0;
        delay_count2 = 5'd0;
        delay_count3 = 5'd0;

        direct_mode = 1'b0;
        valid = 1'b0;

        #10000;
        rst_n = 1'b1;

        #10000;

        // Small-range mode
        direct_mode = 1'b1;

        // Expected delay:
        // sig_sync[0] = 0 * 78 ps =   0 ps
        // sig_sync[1] = 1 * 78 ps =  78 ps
        // sig_sync[2] = 2 * 78 ps = 156 ps
        // sig_sync[3] = 3 * 78 ps = 234 ps
        delay_count0 = 5'd0;
        delay_count1 = 5'd1;
        delay_count2 = 5'd2;
        delay_count3 = 5'd3;

        valid = 1'b1;
        #2500;
        valid = 1'b0;

        #10000;

        $display("============================================================");
        $display("Input rising edge 1");
        $display("Expected output edge difference:");
        $display("sig_sync[1] - sig_sync[0] =  78 ps");
        $display("sig_sync[2] - sig_sync[0] = 156 ps");
        $display("sig_sync[3] - sig_sync[0] = 234 ps");
        $display("============================================================");

        sig_in = 4'b1111;

        #10000;
        sig_in = 4'b0000;

        #10000;

        $display("============================================================");
        $display("Input rising edge 2");
        $display("============================================================");

        sig_in = 4'b1111;

        #10000;
        sig_in = 4'b0000;

        #10000;
        $stop;
    end

    real t0;
    real t1;
    real t2;
    real t3;

    integer got0;
    integer got1;
    integer got2;
    integer got3;

    initial begin
        t0 = 0.0;
        t1 = 0.0;
        t2 = 0.0;
        t3 = 0.0;

        got0 = 0;
        got1 = 0;
        got2 = 0;
        got3 = 0;
    end

    always @(posedge sig_sync[0]) begin
        if (align_valid) begin
            t0 = $realtime;
            got0 = 1;
            check_edges;
        end
    end

    always @(posedge sig_sync[1]) begin
        if (align_valid) begin
            t1 = $realtime;
            got1 = 1;
            check_edges;
        end
    end

    always @(posedge sig_sync[2]) begin
        if (align_valid) begin
            t2 = $realtime;
            got2 = 1;
            check_edges;
        end
    end

    always @(posedge sig_sync[3]) begin
        if (align_valid) begin
            t3 = $realtime;
            got3 = 1;
            check_edges;
        end
    end

    task check_edges;
        begin
            if (got0 && got1 && got2 && got3) begin
                $display("------------------------------------------------------------");
                $display("sig_sync rising edge time:");
                $display("t0 = %0.0f ps", t0);
                $display("t1 = %0.0f ps", t1);
                $display("t2 = %0.0f ps", t2);
                $display("t3 = %0.0f ps", t3);

                $display("edge difference:");
                $display("t1 - t0 = %0.0f ps", t1 - t0);
                $display("t2 - t0 = %0.0f ps", t2 - t0);
                $display("t3 - t0 = %0.0f ps", t3 - t0);
                $display("------------------------------------------------------------");

                got0 = 0;
                got1 = 0;
                got2 = 0;
                got3 = 0;
            end
        end
    endtask

endmodule


module delay_idelay78_sim #(
    parameter integer IODELAY_TAP_PS = 78,
    parameter integer COARSE_DEPTH   = 30
)(
    input  wire       clk_400m,
    input  wire       rst_n,

    input  wire [3:0] sig_in,

    input  wire [4:0] delay_count0,
    input  wire [4:0] delay_count1,
    input  wire [4:0] delay_count2,
    input  wire [4:0] delay_count3,

    input  wire       direct_mode,
    input  wire       valid,

    output wire [3:0] sig_sync,
    output reg        align_valid
);

    reg [4:0] tap0;
    reg [4:0] tap1;
    reg [4:0] tap2;
    reg [4:0] tap3;

    reg [4:0] coarse_cnt0;
    reg [4:0] coarse_cnt1;
    reg [4:0] coarse_cnt2;
    reg [4:0] coarse_cnt3;

    reg mode_r;
    reg load_finish;

    always @(posedge clk_400m or negedge rst_n) begin
        if (!rst_n) begin
            tap0        <= 5'd0;
            tap1        <= 5'd0;
            tap2        <= 5'd0;
            tap3        <= 5'd0;

            coarse_cnt0 <= 5'd0;
            coarse_cnt1 <= 5'd0;
            coarse_cnt2 <= 5'd0;
            coarse_cnt3 <= 5'd0;

            mode_r      <= 1'b0;
            load_finish <= 1'b0;
            align_valid <= 1'b0;
        end
        else begin
            if (valid) begin
                mode_r <= direct_mode;

                tap0 <= delay_count0;
                tap1 <= delay_count1;
                tap2 <= delay_count2;
                tap3 <= delay_count3;

                coarse_cnt0 <= delay_count0;
                coarse_cnt1 <= delay_count1;
                coarse_cnt2 <= delay_count2;
                coarse_cnt3 <= delay_count3;

                load_finish <= 1'b1;
                align_valid <= 1'b1;
            end
        end
    end

    // Manual IDELAY model: 78 ps per tap
    reg [3:0] sig_idelay;

    always @(sig_in[0]) begin
        sig_idelay[0] <= #(tap0 * IODELAY_TAP_PS) sig_in[0];
    end

    always @(sig_in[1]) begin
        sig_idelay[1] <= #(tap1 * IODELAY_TAP_PS) sig_in[1];
    end

    always @(sig_in[2]) begin
        sig_idelay[2] <= #(tap2 * IODELAY_TAP_PS) sig_in[2];
    end

    always @(sig_in[3]) begin
        sig_idelay[3] <= #(tap3 * IODELAY_TAP_PS) sig_in[3];
    end

    // Simple coarse delay model
    reg [COARSE_DEPTH:0] fifo0;
    reg [COARSE_DEPTH:0] fifo1;
    reg [COARSE_DEPTH:0] fifo2;
    reg [COARSE_DEPTH:0] fifo3;

    always @(posedge clk_400m or negedge rst_n) begin
        if (!rst_n) begin
            fifo0 <= {COARSE_DEPTH+1{1'b0}};
            fifo1 <= {COARSE_DEPTH+1{1'b0}};
            fifo2 <= {COARSE_DEPTH+1{1'b0}};
            fifo3 <= {COARSE_DEPTH+1{1'b0}};
        end
        else begin
            fifo0 <= {fifo0[COARSE_DEPTH-1:0], sig_in[0]};
            fifo1 <= {fifo1[COARSE_DEPTH-1:0], sig_in[1]};
            fifo2 <= {fifo2[COARSE_DEPTH-1:0], sig_in[2]};
            fifo3 <= {fifo3[COARSE_DEPTH-1:0], sig_in[3]};
        end
    end

    wire [3:0] coarse_sync;

    assign coarse_sync = {
        fifo3[coarse_cnt3],
        fifo2[coarse_cnt2],
        fifo1[coarse_cnt1],
        fifo0[coarse_cnt0]
    };

    assign sig_sync = (!load_finish) ? 4'b0000 :
                      (mode_r)       ? sig_idelay :
                                       coarse_sync;

endmodule